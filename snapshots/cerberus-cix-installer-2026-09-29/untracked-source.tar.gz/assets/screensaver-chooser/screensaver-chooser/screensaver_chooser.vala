// screensaver_chooser.vala — NCZ-OS Singularity plugin: screensaver chooser.
//
// Renders the four-group screensaver catalogue (Black Hole Simulation,
// hyprsaver, xshadertoy, Classics) inside the Singularity Settings app
// and persists picks via the existing dev.ncz.screensaver GSettings
// schema. The actual saver run/idle-lock runtime is unchanged:
// ncz-idle-manager + ncz-screensaver-run are still the authoritative
// runner; this plugin is the configuration surface only.
//
// No Gtk.Application, no libadwaita, no Gee.ArrayList (uses GLib
// equivalents). Pure native Vala + GTK4 + libsingularity + libpeas-2,
// matching the other 24 Singularity plugins.
//
// Modelled on:
//   subprojects/singularity-plugins/caffeine/caffeine.vala
//   subprojects/singularity-plugins/wallpapers-stock/wallpapers_stock.vala

using Gtk;
using GLib;
using Singularity;
using Peas;

[ModuleInit]
public void peas_register_types (TypeModule module) {
    var objmodule = module as Peas.ObjectModule;
    objmodule.register_extension_type (typeof (Singularity.Plugin),
                                       typeof (ScreensaverChooserPlugin));
}

public class ScreensaverChooserPlugin : Object, Singularity.Plugin {
    private const string CATALOG_PATH = "/usr/share/ncz-screensaver-chooser/hacks.tsv";
    private const string PREVIEWS_DIR = "/usr/share/ncz-screensaver-chooser/previews";

    public void activate (PluginContext context) {
        // Settings-only plugin: no panel/dock/clock widget contribution.
        // The full UI is exposed via get_settings_widget() below.
    }

    public void deactivate () {
        // Nothing to release — get_settings_widget() returns a fresh
        // widget tree on each request and is owned by the Settings app.
    }

    public Gtk.Widget? get_settings_widget () {
        return new ChooserView ();
    }
}

// Hack — one entry from hacks.tsv.
public class ScreensaverHack : Object {
    public string id { get; construct; }
    public string title { get; construct; }
    public string family { get; construct; }
    public string group_name { get; construct; }

    public ScreensaverHack (string id, string title, string family, string group_name) {
        Object (id: id, title: title, family: family, group_name: group_name);
    }
}

// ChooserView — the settings-panel widget tree. Built fresh on every
// get_settings_widget() call so the panel always reflects the current
// GSettings state.
public class ChooserView : Box {
    private GLib.Settings settings;
    private ListBox hacks;
    private ComboBoxText group_filter;
    private Picture preview;
    private Label preview_note;
    private Label count_label;
    private ScreensaverHack? selected;
    private GLib.GenericArray<ScreensaverHack> catalog;

    public ChooserView () {
        Object (orientation: Orientation.VERTICAL, spacing: 12);
        margin_top = 12;
        margin_bottom = 12;
        margin_start = 12;
        margin_end = 12;

        settings = new GLib.Settings ("dev.ncz.screensaver");
        catalog = new GLib.GenericArray<ScreensaverHack> ();
        load_catalog (CATALOG_PATH);

        var heading = new Label ("Screensaver & Lock");
        heading.add_css_class ("title-2");
        heading.halign = Align.START;
        append (heading);

        append (build_modes_row ());
        append (build_paned ());

        var timing_grid = build_timing_grid ();
        append (timing_grid);

        rebuild_list ();
    }

    private Box build_modes_row () {
        var row = new Box (Orientation.HORIZONTAL, 8);

        var off = new CheckButton.with_label ("Off");
        var one = new CheckButton.with_label ("Only one");
        var rnd = new CheckButton.with_label ("Random rotation");
        one.group = off;
        rnd.group = off;

        string mode = settings.get_string ("mode");
        if (mode == "one") one.active = true;
        else if (mode == "random") rnd.active = true;
        else off.active = true;

        off.toggled.connect (() => { if (off.active) settings.set_string ("mode", "off"); });
        one.toggled.connect (() => { if (one.active) settings.set_string ("mode", "one"); });
        rnd.toggled.connect (() => { if (rnd.active) settings.set_string ("mode", "random"); });

        row.append (off);
        row.append (one);
        row.append (rnd);
        return row;
    }

    private Widget build_paned () {
        var paned = new Paned (Orientation.HORIZONTAL);
        paned.position = 360;
        paned.vexpand = true;

        var left = new Box (Orientation.VERTICAL, 8);

        // Group filter — only the four shipping groups.
        group_filter = new ComboBoxText ();
        group_filter.append ("all", "All groups");
        group_filter.append ("Black Hole Simulation", "Black Hole Simulation");
        group_filter.append ("hyprsaver", "hyprsaver");
        group_filter.append ("xshadertoy", "xshadertoy");
        group_filter.append ("Classics", "Classics");
        group_filter.active_id = "all";
        group_filter.changed.connect (rebuild_list);
        group_filter.hexpand = true;
        left.append (group_filter);

        count_label = new Label ("");
        count_label.halign = Align.START;
        count_label.add_css_class ("dim-label");
        left.append (count_label);

        hacks = new ListBox ();
        hacks.selection_mode = SelectionMode.SINGLE;
        hacks.add_css_class ("boxed-list");
        hacks.row_selected.connect (on_selected);

        var scroll = new ScrolledWindow ();
        scroll.vexpand = true;
        scroll.set_child (hacks);
        left.append (scroll);
        paned.start_child = left;

        var right = new Box (Orientation.VERTICAL, 10);
        right.margin_start = 16;

        preview = new Picture ();
        preview.vexpand = true;
        preview.hexpand = true;
        preview.content_fit = ContentFit.CONTAIN;

        preview_note = new Label ("Select a screensaver to see its captured preview.");
        preview_note.wrap = true;

        var preview_button = new Button.with_label ("Preview now");
        preview_button.clicked.connect (launch_preview);

        right.append (preview);
        right.append (preview_note);
        right.append (preview_button);
        paned.end_child = right;

        return paned;
    }

    private Grid build_timing_grid () {
        var grid = new Grid ();
        grid.column_spacing = 12;
        grid.row_spacing = 8;

        var idle = new SpinButton.with_range (1, 240, 1);
        var cycle = new SpinButton.with_range (1, 240, 1);
        var lock_delay = new SpinButton.with_range (0, 240, 1);
        var lock_toggle = new Switch ();

        idle.value = settings.get_int ("hack-idle-delay") / 60.0;
        cycle.value = settings.get_int ("cycle-delay") / 60.0;
        lock_delay.value = settings.get_int ("lock-delay") / 60.0;
        lock_toggle.active = settings.get_boolean ("lock-enabled");

        idle.value_changed.connect (() => settings.set_int ("hack-idle-delay", (int)(idle.value * 60)));
        cycle.value_changed.connect (() => settings.set_int ("cycle-delay", (int)(cycle.value * 60)));
        lock_delay.value_changed.connect (() => settings.set_int ("lock-delay", (int)(lock_delay.value * 60)));
        lock_toggle.notify["active"].connect (() => settings.set_boolean ("lock-enabled", lock_toggle.active));

        grid.attach (new Label ("Start after (minutes)"), 0, 0);
        grid.attach (idle, 1, 0);
        grid.attach (new Label ("Rotate after (minutes)"), 2, 0);
        grid.attach (cycle, 3, 0);
        grid.attach (new Label ("Lock after screensaver"), 4, 0);
        grid.attach (lock_toggle, 5, 0);
        grid.attach (new Label ("Lock delay (minutes)"), 6, 0);
        grid.attach (lock_delay, 7, 0);
        return grid;
    }

    private void load_catalog (string path) {
        try {
            string data;
            FileUtils.get_contents (path, out data);
            foreach (string line in data.split ("\n")) {
                if (line == "" || line.has_prefix ("#")) continue;
                string[] f = line.split ("\t");
                if (f.length == 4) catalog.add (new ScreensaverHack (f[0], f[1], f[2], f[3]));
            }
        } catch (Error e) {
            warning ("screensaver-chooser: cannot load catalog %s: %s", path, e.message);
        }
    }

    private void rebuild_list () {
        Widget? child;
        while ((child = hacks.get_first_child ()) != null) hacks.remove (child);

        string grp = group_filter.active_id ?? "all";
        int visible = 0;
        foreach (ScreensaverHack hack in catalog) {
            if (grp != "all" && hack.group_name != grp) continue;

            var row = new ListBoxRow ();
            var box = new Box (Orientation.HORIZONTAL, 8);
            box.margin_top = box.margin_bottom = 7;
            box.margin_start = box.margin_end = 9;

            var enabled = new CheckButton ();
            enabled.tooltip_text = "Include in random rotation";
            enabled.active = random_contains (hack.id);
            enabled.toggled.connect (() => update_random (hack.id, enabled.active));

            var labels = new Box (Orientation.VERTICAL, 2);
            var name = new Label (hack.title);
            name.halign = Align.START;
            name.add_css_class ("heading");
            var detail = new Label (hack.group_name);
            detail.halign = Align.START;
            detail.add_css_class ("dim-label");
            labels.append (name);
            labels.append (detail);

            box.append (enabled);
            box.append (labels);
            row.set_child (box);
            row.set_data<ScreensaverHack> ("hack", hack);
            hacks.append (row);
            visible++;
        }
        count_label.label = "%d of %d screensavers".printf (visible, (int) catalog.length);
    }

    private bool random_contains (string id) {
        foreach (string current in settings.get_strv ("random-hacks"))
            if (current == id) return true;
        return false;
    }

    private void update_random (string id, bool enabled) {
        // Build a null-terminated string[] for gsettings. Same shape
        // singularity-shell uses in PluginManager.set_plugin_enabled —
        // gee's to_array() is NOT safe here (g_settings_set_strv expects
        // a null-terminated array; gee_collection_to_array omits the
        // sentinel).
        string[] next = {};
        foreach (string current in settings.get_strv ("random-hacks"))
            if (current != id && current != null && current.length > 0) next += current;
        if (enabled) next += id;
        settings.set_strv ("random-hacks", next);
    }

    private void on_selected (ListBoxRow? row) {
        if (row == null) return;
        selected = row.get_data<ScreensaverHack> ("hack");
        if (selected == null) return;
        settings.set_string ("hack-id", selected.id);

        string file = "%s/%s.png".printf (PREVIEWS_DIR, selected.id);
        if (FileUtils.test (file, FileTest.EXISTS)) {
            preview.set_filename (file);
            preview_note.label = "%s — captured on a real NCZ-OS Wayland session".printf (selected.title);
        } else {
            preview.set_paintable (null);
            preview_note.label = "%s has no packaged capture yet. Use Preview now to run it on this display.".printf (selected.title);
        }
    }

    private void launch_preview () {
        if (selected == null) return;
        try {
            Process.spawn_command_line_async (
                "/usr/libexec/ncz-screensaver-run --preview %s".printf (Shell.quote (selected.id)));
        } catch (SpawnError e) {
            preview_note.label = "Could not launch preview: %s".printf (e.message);
        }
    }
}
