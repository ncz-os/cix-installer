# Retire Bookworm as the d-i substrate; standardize on Forky's own d-i, both arches

## Status of this task -- read first

Operator directive, given AFTER real evidence: (1) a full architectural
review concluded Bookworm was never actually load-bearing on either
arch (docs/superpowers/specs/2026-09-21-multiarch-modernization-bookworm-elimination-review.md),
(2) a Stage A/B dispatch proved arm64's F-stock-userspace (stock Forky d-i
+ only the mandatory Sky1 kernel/module/firmware swap, none of the 4
Sky1-specific hardware-fix overlays) passes install+boot cleanly while
F-retained-fixes (with all 4 overlays) times out on QEMU/TCG
(docs/superpowers/specs/2026-09-21-arm64-forky-qualification-stage-ab.md),
(3) a companion amd64 dispatch found stock Forky d-i installs cleanly
once real preseed-completeness gaps are filled
(docs/superpowers/specs/2026-09-21-amd64-forky-qualification-stage-ab.md),
(4) a consolidated recommendation with a concrete order of work exists
(docs/superpowers/specs/2026-09-21-bookworm-elimination-consolidated-recommendation.md),
and (5) **tonight, for real, on real O6N Sky1 hardware, human-supervised,
the arm64 F-stock-userspace build was installed AND BOOTED successfully**
-- confirmed live via serial console, no oops/panic, reached the NCZ-OS
banner. This is no longer a hypothesis to test further -- it is a
directive to make Forky's own d-i the PRODUCTION default, retiring
Bookworm, on THIS branch (`retire-bookworm-forky-di-2026-09-21`, forked
from the real production branch `wip/mkosi-pipeline-2026-09-14` at
commit `bcdc680`).

Read all four docs above in full before starting. Do not re-derive their
findings -- implement the recommended-order items they already specify.

## Scope: ONE deliverable, both arches, in this order

Follow docs/superpowers/specs/2026-09-21-bookworm-elimination-consolidated-recommendation.md's
"Recommended order of work" table exactly, items 1-5 (item 6, Stage C,
is explicitly NOT part of this dispatch -- see HARD BOUNDARY below).
Concretely:

1. **arm64: flip `NCZ_SKY1_OVERLAYS` default from 1 to 0.** Find the
   actual default declaration in `build/build-iso-di.sh` (grep
   `NCZ_SKY1_OVERLAYS`). Keep the overlay CODE PATH intact (do not delete
   it) in case a future kernel/substrate regression needs it back -- just
   stop applying it by default. Document why in a comment citing this
   commit and the Stage A/B evidence.

2. **Decompose the arm64 overlay gate.** The consolidated doc found only
   2 of the 4 "Sky1 hardware fixes" (disk-detect wait extension,
   S35usb-rescan) actually touch Sky1 hardware; the other 2
   (finish-install progress-owner, sshd-watcher DNS writer) are generic
   d-i quality-of-life patches mis-classified as hardware fixes. Split
   them into separately-gated code paths so the generic ones can be
   evaluated/kept independently of the Sky1-specific ones.

3. **amd64: port the proven preseed additions from the Stage A/B dispatch
   into the REAL `preseed/preseed.cfg`** (not a side-script): the
   `preseed/url=file://...` + `DEBCONF_PRIORITY=critical` kernel-cmdline
   fix, `passwd/*` answers, `partman-auto/*` method + confirm keys, an
   explicit `efi` partman recipe method, and `finish-install/reboot_in_progress`.
   These are documented with exact values in
   docs/superpowers/specs/2026-09-21-amd64-forky-qualification-stage-ab.md
   §2 and in the dispatch's own gate scripts
   (`build/dispatch2-amd64/kvm-install-gate-amd64-stock.sh` on branch
   `wip/stock-forky-di-2026-09-21` -- pull that branch to read them, do
   not guess the values). Gate any Bookworm-only preseed branches so they
   no longer apply for a Forky substrate (some may already be
   dead-but-present per the architectural review's findings -- verify
   and remove genuinely dead code, don't just add new code on top of it).

4. **Make Forky's own d-i the DEFAULT/ONLY substrate input on both
   arches** for the `full` build mode. `build/build-iso-di.sh`'s
   `--bookworm-iso`/`--installer-iso` flag (dispatch 1 already added the
   `--installer-iso` alias, verify it is actually present on this branch
   after your rebase/merge -- if not, port it from commit `f4f96ab` on
   branch `wip/stock-forky-di-2026-09-21`) should now be pointed at a
   Forky netinst by the actual build scripts/Makefile that invoke it
   (`run-fresh-amd64*.sh`-style scripts, `Makefile`'s arm64 `download`
   target) -- update the DEFAULT URL/pin, not just the flag name. Remove
   or explicitly gate-as-legacy-only any code path in `build-iso-di.sh`
   that exists ONLY for Bookworm (the Trixie debootstrap/libzstd graft at
   the line the architectural review cites, the cdebconf-newt
   amber-phosphor binary patch, the gutsy/Ubuntu foreign-suite
   debootstrap naming) -- per the review, these already no-op on Forky;
   confirm that and then actually remove the dead code rather than
   leaving it silently unreachable.

5. **Fix `build/kvm-installed-disk-assert.sh`'s qcow2/`parted` limitation**
   (documented in both Stage A/B docs -- `parted -s <qcow2>` cannot read
   a qcow2's partition table directly, causing a false GPT-missing
   report on some layouts). Switch to `sgdisk --verify` or qemu-nbd
   indirection, whichever is more robust. This gate needs to be TRUSTWORTHY
   before it becomes the real production gate for the retired-Bookworm
   path.

## HARD BOUNDARY

**No real physical hardware boot as part of this dispatch.** Sky1/O6N's
Stage C validation for the SPECIFIC artifact this dispatch produces has
NOT happened yet (tonight's real O6N boot was of the SEPARATE,
already-built `ncz-d2-stock-2026.09.21.iso` from the earlier dispatch,
not of whatever new ISO this dispatch builds) -- everything here is
QEMU/KVM virtual-gate validation only, on both arches. A human-supervised
real O6N boot-test of THIS dispatch's actual output ISO is a separate,
later, operator-authorized step, exactly like every other kernel/boot
change tonight.

## Validation required before reporting done

- `bash build/preflight-freshness-gate.sh` clean on this branch.
- A REAL, full amd64 build (`make`-equivalent or the `run-fresh-amd64.sh`
  pattern already used tonight on this host) using Forky as the ONLY
  substrate input, through `build/kvm-install-gate-amd64.sh`, GATE PASS,
  confirmed booting the correct default kernel (same class of check used
  all night: `Starting vmlinuz-...` banner + login/systemd reaching
  userspace).
- A REAL, full arm64 build (dispatch to a fresh checkout on an
  arm64-capable host if this dispatch's own host is amd64-only -- ULTRA
  is currently occupied by a kernel-port dispatch tonight, check its
  availability before assuming it is free, or use TYDEUS) through
  `build/kvm-kernel-gate.sh` AND a full install+boot via
  `build/kvm-install-gate.sh`, GATE PASS.
- zoder adversarial review (directive 6) on the diff before considering
  this ready -- this is now a real production-targeted change, not an
  experiment; fix any real finding in place, re-review until APPROVE.
- Commit incrementally (one logical change per commit: overlay-default
  flip, preseed port, substrate-default change, disk-assert fix), push
  to this branch after each, per the concurrent-push-collision lesson
  already learned twice tonight (rebase immediately before each push).

## Deliverable

A clean, real diff on `retire-bookworm-forky-di-2026-09-21` with BOTH
arches gate-passing on Forky as the sole substrate, zoder-reviewed, ready
for the operator to review and merge into the real production branch
(`wip/mkosi-pipeline-2026-09-14`) themselves -- do NOT merge to production
as part of this dispatch, that is the operator's own call. Write a short
findings doc summarizing exactly what changed, what was removed as dead
Bookworm-only code, and the two gate-pass receipts (amd64 + arm64).
