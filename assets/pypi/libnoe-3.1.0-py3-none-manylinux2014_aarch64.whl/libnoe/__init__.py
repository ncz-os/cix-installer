import sys
import os
import glob
import importlib.util

_SO_MAP = {
    (3, 10): "libnoe.cpython-310-aarch64-linux-gnu.so",
    (3, 11): "libnoe.cpython-311-aarch64-linux-gnu.so",
    (3, 12): "libnoe.cpython-312-aarch64-linux-gnu.so",
    (3, 13): "libnoe.cpython-313-aarch64-linux-gnu.so",
    (3, 14): "libnoe.cpython-313-aarch64-linux-gnu.so",
}

package_dir = os.path.dirname(__file__)

filename = _SO_MAP.get(sys.version_info[:2])
file_path = os.path.join(package_dir, filename) if filename else None

if not file_path or not os.path.exists(file_path):
    so_files = glob.glob(os.path.join(package_dir, "libnoe.cpython-*-aarch64-linux-gnu.so"))
    if so_files:
        file_path = so_files[0]
    else:
        import ctypes.util
        alt = ctypes.util.find_library("libnoe")
        if alt:
            file_path = alt
        else:
            raise ImportError("No libnoe shared library found")

if not os.path.exists(file_path):
    raise ImportError("Shared library not found: " + file_path)

spec = importlib.util.spec_from_file_location("libnoe", file_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
globals().update({n: getattr(module, n) for n in dir(module) if not n.startswith("__")})
